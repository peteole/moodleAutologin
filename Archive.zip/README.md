# moodleAutologin
This is a browser extension allowing you to auto login to moodle at TUM, saving your valuable time.

## How to use

You will automatically be navigated to the login page from moodle.tum.de, the "keep me logged in" checkbox will be filled out correctly, the submit button will be focused so the only thing you have to do is pressing Enter. Then you are logged in to moodle.
### Chrome
Clone this repo, got to extensions, enable developer mode, click "load unpacked".
### Firefox
Clone this repo, go to about:addons, click Extensions, settings, load from file, select the fx.xpi file from this repo
